# CNP - Processeur en VHDL

> Rapport final des 3 séances
>
> Par Antoine DUQUENOY & Anthony DUROT



# I / Séance 1 : afficheurs 7-segments et diviseur

## Schéma de principe global

La première partie de ce TP consistait en la réalisation d'un diviseur de fréquence et d'un second module gérant l'affichage de 4 symboles sur les afficheurs 7-segments. *SevenDisp* utilise un signal d'horloge de 200 Hz, c'est pourquoi son entrée *clk* est reliée au diviseur de fréquence. Ces 2 blocs interagissant ensemble, il a été nécessaire d'en créer un troisième (*SevenTop*) pour les contenir.

On retrouve en entrée de ce module *top* la *clock* interne de 100 MHz et en sortie 2 bus de données *oDisp* et *oSel* permettant l'affichage des symboles.

![CNP_Schema](Images\CNP_Schema.JPG)

## Module 1 : Diviseur de fréquence

L'objectif de ce module est de récupérer en sortie 2 signaux d'horloge, un à 200 Hz pour le multiplexage des afficheurs 7-segments et un autre d'1 Hz utilisé pour cadencer le processeur à basse vitesse afin de pouvoir suivre le déroulement des instructions du programme.  

L'horloge interne étant de 100 MHz, nous pouvons déterminer le cycle nécessaire pour simuler de telles fréquences.
$$
c_{1max} = \frac{100.10^6}{200} = 500\,000  \; \; \; \; ; \; \; \; \;  c_{2max} = 100\,000\,000
$$
Pour générer $$f_1 = 200 Hz$$, une variable s'incrémente jusqu'à $$c_{1max}$$ et repasse à `0` ensuite. Dans cet intervalle, *oClk1* vaut `0` de $$0$$ à $$\frac{c_{1max}}{2}$$ et `1` le reste du temps. On procède de la même manière pour la *clock* de fréquence 1 Hz.

```vhdl
process(iClk)

variable c1 : integer range 0 to 500000 := 0;
variable c2 : integer range 0 to 100000000 := 0;

begin

if(rising_edge(iClk)) then
    
    if(c1 = 500000) then
        c1 := 0;
    end if;
    if(c2 = 100000000) then
        c2 := 0;
    end if;
    if(c1 <= 250000) then
        oClk1 <= '0';
    else
        oClk1 <= '1';
    end if;
    if(c2 <= 50000000) then
        oClk2 <= '0';
    else
        oClk2 <= '1';
    end if;
    c1 := c1 + 1;
    c2 := c2 + 1;

end if;
```



## Module 2 : Affichage 7-Segments

Ce module comporte 2 entrées, *clk* et *iData* et 2 sorties *oAff* et *oSel*. La *clock* utilisée est de 200 Hz, ce qui permet de multiplexer les afficheurs pour tromper l'oeil et ainsi afficher un nombre composé de 4 symboles hexadécimaux. *iData* est un bus de 20 bits découpé en 5 parties de 4 bits comme précisé ci-dessous.

![7segData](Images\7segData.JPG)

Le résultat visible de cette donnée sur les afficheurs est le suivant :

![7seg](Images\7seg.JPG)

Une variable *sel* assure le multiplexage en s'incrémentant de 0 à 3. Ainsi, les afficheurs seront successivement activés de droite à gauche à une fréquence de 200 Hz. Le `case sel` permet de sélectionner le code BCD à afficher et éventuellement le point, le `case Disp8` joue le rôle du convertisseur BCD vers 7-segments et enfin le second `case sel` sert de démultiplexeur pour sélectionner l'afficheur à activer.

```vhdl
process(clk,iData)

variable sel: STD_LOGIC_VECTOR(2 downto 0);
variable aff: STD_LOGIC_VECTOR(7 downto 0);
variable point: STD_LOGIC;
variable Disp8: STD_LOGIC_VECTOR(3 downto 0);    

begin
    if(rising_edge(clk)) then
        sel := sel+1;
		if(sel = "100") then
   			sel := "000";
		end if;
            
        case sel is
        	when "00" =>
            	Disp8 := iData(3 downto 0);
    			point := iData(16);
			[...]
			when "11" =>
    			Disp8 := iData(15 downto 12);
				point := iData(19);
		end case;

    	case Disp8 is
        	when "0000" =>
        		aff := "11111100";
			[...]
			when "1111" =>
    			aff := "10001110";
		end case;

    	case sel is
        	when "00" =>
        		oSelect <= "0001";
    		[...]  
    		when "11" =>
   				oSelect <= "1000";
		end case;

        aff(0) := point;		
        oAff <= NOT aff;

    end if;
    
end process;
```

A noter ici qu'il nous a fallu appliquer un *NOT* (ligne 42) pour respecter la logique inverse stipulée dans la datasheet de la *board*. Ce détail ainsi qu'un oublie dans le fichier de contraintes nous ont coûté quelques dizaines de minutes de réflexion durant la seconde séance.

Finalement, par le biais du fichier de contraintes, les bits de *oAff* et *oSel* seront assignés sur des sorties physiques de la *Basys 3*.

# II / Séance 2 : ROM, RAM et instructions

## Le jeu d'instructions initial

Avant tout, nous avons travaillé sur le jeu d'instructions acceptable par notre CPU. 

| Code binaire | Instruction | Conséquences              |
| ------------ | ----------- | ------------------------- |
| 0000         | STORE       | *ADR <- $R_k$             |
| 0001         | LOAD        | $R_k$ <- *ADR             |
| 0010         | LOADI       | $R_k$ <- K                |
| 0011         | JMP         | PC <- K                   |
| 0100         | RJMP        | PC <- PC + K              |
| 0101         | LSR         | $R_k$ >> 1                |
| 0110         | LSL         | $R_k$ << 1                |
| 0111         | ADD         | $R_i$ <- $R_i$ + $R_j$    |
| 1000         | NAND        | $R_k$ <- $R_i$ NAND $R_j$ |
| 1001         | XOR         | $R_k$ <- $R_i$ XOR $R_j​$  |

Nous avions fait le choix de travailler sans accumulateur, choix qui a vite été remis en question en séance 3 lors de l'écriture de la FSM articulant les actions *fetch*, *decode* et *execute*. Nous n'arrivions pas à faire en sorte de réaliser une instruction comme le *ADD* en 3 coups d'horloge sachant qu'il fallait réécrire le résultat dans un des registres à la fin.





## Bloc RAM et ROM

Ensuite, nous avons décidé de travailler avec une ROM d'une taille de 32 mots de 20 bits permettant de gérer les instructions avec valeur immédiate. 

Ainsi, le programme suivant

```
R1 <- 7
R2 <- 1
R1 <- R1 + R2
*ADR(0) <- R1 
```

s'écrirait en binaire de la sorte :

```
0010 00000001 00000111
0010 00000010 00000001
0111 00001010 00000011
0000 00000001 00000000
```

Concernant la RAM, elle est similaire à la ROM avec comme différence la taille des mots qui sont de 8 bits. Elle contient également les registres qui ne sont rien d'autre que des emplacements en RAM. Le code VHDL de ces modules seront évidemment dans le zip rendu.

Pour finir, nous avons commencé en fin de séance à rédiger le module au coeur du CPU, la FSM avec comme actions FETCH, DECODE, EXECUTE. La partie FETCH semble être terminée et pour DECODE  et EXECUTE nous avons l'idée globale, il nous restera à écrire tout ça en VHDL lors de la prochaine séance.

# III / Séance 3 : FSM, ALU et changements

## Nouveau jeu d'instructions

Pour les raisons évoquées précédemment, nous avons élaboré un nouveau jeu d'instructions composé des actions suivantes : *STORE*, *LOAD*, *LOADI*, *JUMP*, *RJUMP*, *ADD*, *AND* et *OR*. Le *LOADI* nous servira à initialiser différentes valeurs dans la RAM.

## FSM et ALU, l'articulation du CPU

Notre machine à états comporte 3 états *FETCH*, *DECODE* et *EXECUTE*. A chaque coup d'horloge, le premier processus stimulé par `iClk` change l'état de la machine. Ensuite, un autre processus stimulé par l'état courant et doté d'un `case` sur les 3 états se chargent de réaliser les actions.

```vhdl
begin
    
    process(iClk) 
        begin 
            if(rising_edge(iClk)) then         
                current_state <= next_state;                                       
            end if;                                                      
    end process;   
                
    process(current_state)
    
    variable sel: STD_LOGIC_VECTOR(3 downto 0);
    variable value: STD_LOGIC_VECTOR(7 downto 0);   

    begin                                                                                     
        
        case current_state is
            
            when FETCH =>
            
                oPC <= PC;
                oReadROM <= '1';
                IR <= iIR;
                PC <= PC+1;                                                 
                next_state <= DECODE;           
```

Le *FETCH* va dans un premier temps indiquer l'adresse de la ROM où se situe l'instruction qu'il souhaite. Il copie ensuite dans un signal `IR` l'instruction complète qui correspond. Enfin, il incrémente le pointeur de programme et indique l'état suivant.

```vhdl
            when DECODE =>
                
                sel := IR(19 downto 16);
                
                case sel is
                    when "0000" =>
                        oWriteRAM <= '1';
                        oAddrRAM <= IR(15 downto 8);
                                            
                    when "0001" =>
                        oReadRAM <= '1';
                        oAddrRAM <= IR(7 downto 0);
                                                           
                    when "0111" => --ADD
                        oReadRAM <= '1';
                        oAddrRAM <= IR(7 downto 0);
                        value := iData;
                                            
                    when "1000" => --AND
                        oReadRAM <= '1';
                        oAddrRAM <= IR(7 downto 0);
                        value := iData;
                             
                    when "1001" => --OR 
                        oReadRAM <= '1';
                        oAddrRAM <= IR(7 downto 0);
                        value := iData;   
                                               
                end case; 
                    
                next_state  <= EXECUTE; 
```

La partie *DECODE* va permettre d'interpréter le code binaire de l'instruction et de préparer certains signaux / variables pour l'étape suivante. Au niveau de la ligne 3, on vient affecter le code de l'instruction et on réalise ensuite un `case` sur cette même variable. Prenons l'exemple du *ADD* : on commence par mettre la RAM en mode lecture puis on indique l'adresse où l'on va lire contenu dans l'instruction. Finalement, on stocke dans une variable cette valeur lue sur le bus de données *iData*. 

```vhdl
            when EXECUTE => 
            
                case sel is
                    when "0000" => --STORE
                        oData <= ACC;

                    when "0001" => --LOAD
                        ACC <= iData;    
                                     
                    when "0010" => --LOADI
                        oWriteRAM <= '1';
                        oAddrRAM <= IR(15 downto 8);
                        oData <= IR(15 downto 8);   
                                                  
                    when "0011" => --JUMP
                        PC <= IR(15 downto 8);
                        
                    when "0100" => --RJUMP
                        PC <= PC+IR(15 downto 8)-1;
                              
                    when "0111" => --ADD
                        ACC <= ACC + value;
                        
                    when "1000" => --AND
                        ACC <= ACC AND value;
                    
                    when "1001" => --OR
                        ACC <= ACC OR value;                               
                end case;       
                    
                next_state  <= FETCH;   

        end case;   
            
    end process;  
            
   oDisplay <= ACC;  

end Behavioral;
```

C'est durant cette étape où les instructions seront effectivement réalisées. A souligner que nous avons fait le choix d'inclure l'ALU à notre FSM au vu du faible nombre d'instructions. Pour continuer sur l'exemple précédent, on voit que la valeur ciblée dans la RAM et ajoutée à l'accumulateur. Autre exemple, nous voyons que pour le *RJUMP* nous changeons la valeur du PC relativement et sans oublier de retrancher 1 car le PC a déjà été incrémenté dans le FETCH.

## IV / Schéma global et conclusion

Au final, le projet se compose de 6 fichiers vhd dont 2 ne servent qu'à unifier le système complet grâce aux `port map`. 

`CPU.vhd` est fichier réunissant FSM, RAM et ROM. Son schéma de principe est le suivant :

![cpu](Images\cpu.JPG)

Le CPU peut être cadencé à n'importe quelle fréquence au moyen de l'entrée *iClk* et retourne en sortie la valeur de l'accumulateur sur 8 bits. A noter que seul 2 afficheurs au maximum seront utilisés.

Ensuite, nous avons trouvé judicieux de réunir toutes les parties du système dans le fichier `SevenTop.vhd` créé en séance 1. Au final, nous avons obtenu le schéma complet suivant :

![global](Images\global.JPG)

En fin de dernière séance, nous avons manqué d'un peu de temps pour tester notre projet néanmoins la compilation, la synthèse et l'implémentation se sont faits sans erreurs. On constate également que le schéma global final correspond aux attentes que nous avions au départ. Nous sommes bien entendu frustrés de ne pas avoir vu le CPU en fonctionnement. Le temps perdu à debugger notre vhd pour les afficheurs 7-segments en séance 2 en est surement pour quelque chose. On en retire tout de même une bonne expérience qui nous a obligé à réfléchir et concevoir différemment en amont les modules créés.

